package co.kr.brisbane;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import java.util.*;//HashMap ���
import org.springframework.beans.factory.annotation.Autowired;
import org.apache.ibatis.session.SqlSession; //MyBatis ���
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import java.io.IOException;
import javax.naming.NamingException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.ui.Model;

import model.member.MemberDto;
import model.notice.NoticeDto;
import model.reply.ReplyDto;

@Controller
public class NoticeController {
	
	@Autowired
	private SqlSession sqlSession;
	
	//�۾��� ��
	@RequestMapping("/noticeWrite.do")
	public String writeForm(Model model, String num, String ref, String re_step, String re_level, String pageNum, HttpServletRequest request) {
		
		if(num==null) {
			num = "0";
			ref = "1";
			re_step = "0";
			re_level = "0";
		}//if
		
		HttpSession session=request.getSession();
		String writer=(String)session.getAttribute("name");
		model.addAttribute("writer", writer);
		
		model.addAttribute("num", new Integer(num));
		model.addAttribute("pageNum", pageNum);
		model.addAttribute("ref", new Integer(ref));
		model.addAttribute("re_step", new Integer(re_step));
		model.addAttribute("re_level", new Integer(re_level));
		
		return ".main.notice.noticeWrite";
	}//writeForm()
	
	//DB�۾���
	@RequestMapping(value="/noticeWritePro",method=RequestMethod.POST)
	public String writePro(@ModelAttribute("noticeDto") NoticeDto noticeDto, HttpServletRequest request) 
			throws IOException, NamingException {
		
		int maxnum = 0;
		if(sqlSession.selectOne("notice.nMaxnum") != null) {
			maxnum = sqlSession.selectOne("notice.nMaxnum");
		}//if
		
		if(maxnum != 0) {
			maxnum = maxnum+1;
		}else {
			maxnum = 1;
		}//else
		
		String ip = request.getRemoteAddr();
		noticeDto.setIp(ip);
		
		if(noticeDto.getNum() != 0) {//����϶�
			sqlSession.update("notice.nRestep", noticeDto);
			noticeDto.setRe_step(noticeDto.getRe_step()+1);
			noticeDto.setRe_level(noticeDto.getRe_level()+1);
		}else {
			noticeDto.setRef(new Integer(maxnum));
			noticeDto.setRe_step(new Integer(0));
			noticeDto.setRe_level(new Integer(0));
		}//else
		
		sqlSession.update("notice.insertNotice", noticeDto);
		
		return "redirect:noticeList.do";
	}//writePro()
	
	//����Ʈ
	@RequestMapping("/noticeList.do")
	public String noticeList(Model model, String pageNum) throws IOException, NamingException {
		
		if(pageNum==null) {pageNum = "1";}
		
		int pageSize = 10;
		int currentPage = Integer.parseInt(pageNum);
		int startRow = (currentPage-1)*pageSize+1;//�������� ó��row
		int endRow = currentPage*pageSize;//�������� ������ row
		int pageBlock = 10;
		int count = 0;
		
		count = sqlSession.selectOne("notice.nCount");//�� �۰���
		
		int number = count-(currentPage-1)*pageSize;//�۹�ȣ
		int pageCount = count/pageSize+(count%pageSize==0?0:1);//�� ������ ����
		int startPage = (currentPage/10)*10+1;//����������
		int endPage = startPage+pageBlock-1;//������������
		
		HashMap<String,Integer> map = new HashMap<String,Integer>();
		map.put("start", startRow-1);
		map.put("cnt", pageSize);
		
		List<NoticeDto> list = sqlSession.selectList("notice.noticeList", map);
		model.addAttribute("pageSize", pageSize);
		model.addAttribute("currentPage", currentPage);
		model.addAttribute("startRow", startRow);
		model.addAttribute("endRow", endRow);
		model.addAttribute("pageBlock", pageBlock);
		model.addAttribute("count", count);
		model.addAttribute("number", number);
		model.addAttribute("pageCount", pageCount);
		model.addAttribute("startPage", startPage);
		model.addAttribute("endPage", endPage);
		model.addAttribute("list", list);
		
		return ".main.notice.noticeList";
	}//noticeList()
	
	//�۳��뺸��/��ȸ������
	@RequestMapping("/noticeContent.do")
	public String noticeContent(Model model, String num, String pageNum) throws IOException, NamingException {
		
		int num1 = Integer.parseInt(num);
		sqlSession.update("notice.nReadcount", num1);
		
		//�۳��뺸��
		NoticeDto noticeDto = sqlSession.selectOne("notice.getNotice", num1);
		String content = noticeDto.getContent();
		model.addAttribute("content", content);
		model.addAttribute("num", num1);
		model.addAttribute("pageNum", pageNum);
		model.addAttribute("noticeDto", noticeDto);
		
		List<ReplyDto> replyList = sqlSession.selectList("reply.replyList",num1);
		model.addAttribute("replyList", replyList);
		
		return ".main.notice.noticeContent";
	}//noticeContent()
	
	//�ۼ�����
	@RequestMapping("/noticeUpdate.do")
	public ModelAndView noticeUpdate(String num, String pageNum, HttpServletRequest request) throws IOException, NamingException {
		
		int num1 = Integer.parseInt(num);
		NoticeDto noticeDto = sqlSession.selectOne("notice.getNotice", num1);
		
		ModelAndView mv = new ModelAndView();
		mv.addObject("pageNum", pageNum);
		mv.addObject("noticeDto", noticeDto);
		mv.setViewName(".main.notice.noticeUpdate");
		
		return mv;
	}//noticeUpdate()
	
	//DB�ۼ���
	@RequestMapping(value="/noticeUpdatePro.do",method=RequestMethod.POST)
	public ModelAndView noticeUpdatePro(NoticeDto noticeDto, String pageNum, HttpServletRequest request) 
			throws IOException, NamingException {
		
		String ip = request.getRemoteAddr();
		noticeDto.setIp(ip);
		
		sqlSession.update("notice.updateNotice", noticeDto);
		
		ModelAndView mv = new ModelAndView();
		mv.addObject("pageNum", pageNum);
		mv.setViewName("redirect:noticeList.do");
		
		return mv;
	}//noticeUpdatePro()
	
	//�ۻ���
	@RequestMapping("/noticeDelete.do")
	public String noticeDelete(Model model, String num, String pageNum) throws IOException, NamingException {
		
		sqlSession.delete("notice.deleteNotice", new Integer(num));
		model.addAttribute("pageNum", pageNum);
		
		return "redirect:noticeList.do";
	}//noticeDelete()
	
	
	
}//class
